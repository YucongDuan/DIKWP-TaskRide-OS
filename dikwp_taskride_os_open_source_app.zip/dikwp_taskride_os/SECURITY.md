# Security

This offline core intentionally avoids network calls, subprocess execution, browser automation, credential handling, payment execution, and external system mutation.
