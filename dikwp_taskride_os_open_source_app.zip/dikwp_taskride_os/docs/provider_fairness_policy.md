# Provider Fairness Policy

TaskRide must not become a race-to-the-bottom labor platform.

Principles:

- Transparent pricing.
- Skill-based matching.
- Minimum review standards.
- No fake ratings.
- Provider right to reject unsafe tasks.
- Clear audit and dispute process.
