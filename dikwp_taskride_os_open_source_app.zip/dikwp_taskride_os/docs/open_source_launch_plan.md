# Open Source Launch Plan

1. Publish as `dikwp-taskride-os`.
2. Pin demo outputs in README.
3. Release v0.1.0 with research, support, legal high-risk, code review examples.
4. Invite contributors to add task category adapters.
5. Keep live payments and provider registry outside open-source core.
6. Offer paid DIKWP TaskRide Pilot Review for enterprises.
