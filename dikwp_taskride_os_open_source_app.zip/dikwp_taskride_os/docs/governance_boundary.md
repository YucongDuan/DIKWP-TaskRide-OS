# Governance Boundary

TaskRide OS does not perform real-world actions. It routes tasks to draft, review, expert review, block or scope rewrite.

## Blocked

- Credential collection.
- Payment execution.
- Automatic firing, hiring, medical, legal, finance or public-safety decisions.
- Platform bypass, CAPTCHA bypass, hidden browser automation.
- Fake reviews, provider exploitation, opaque pricing.

## Required

- D/I/K/W/P/R registration.
- Evidence or residual ledger.
- Action Ticket.
- Kill/Recovery.
- Human review when risk exceeds threshold.
