# Pricing Model

Prototype quote:

```text
base = estimated_hours * provider_rate
risk_multiplier = 1 + 0.18 * risk_level
total = base * risk_multiplier + review_surcharge + rush_surcharge
```

Pricing must remain explainable. The system should not hide algorithmic fees.
