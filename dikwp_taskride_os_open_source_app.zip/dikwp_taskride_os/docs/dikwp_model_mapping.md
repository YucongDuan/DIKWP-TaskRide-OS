# DIKWP Model Mapping

- D: task text, files, evidence, budget, deadline, requester information.
- I: relationships among task, provider, evidence, risk, output, action ticket.
- K: domain rules, task taxonomy, provider capabilities, risk levels.
- W: fairness, safety, consent, worker protection, professional boundary, review necessity.
- P: task goal, value, constraints, time window, feedback plan.
- R: provider reliability, evidence sufficiency, semantic stability, residuals, kill conditions.
