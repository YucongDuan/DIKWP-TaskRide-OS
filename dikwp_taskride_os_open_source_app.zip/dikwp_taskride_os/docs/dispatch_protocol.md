# Dispatch Protocol

## Step 1: Intake
The task is registered as a DIKWP object.

## Step 2: Three-No SemanticClosure
Incomplete, imprecise and inconsistent fields are not discarded. They become residuals, clarifying questions, provisional pricing or Kill Conditions.

## Step 3: Risk Tier
C0-C6 task risk determines autonomy. C3+ requires human review. C4+ requires professional or organization-level review. C6 blocks.

## Step 4: Matching
Match by domain, capability, reliability, availability, cost and max risk level.

## Step 5: Ticketing
Every dispatch generates an Action Ticket with evidence refs and rollback plan.
