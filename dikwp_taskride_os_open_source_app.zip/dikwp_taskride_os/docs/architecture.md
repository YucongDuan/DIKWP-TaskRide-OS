# Architecture

```text
Task Intake
  -> DIKWP Task Capsule
  -> SemanticClosure / 3NO Analysis
  -> Risk Level C0-C6
  -> Provider Matching
  -> Pricing Quote
  -> Action Ticket
  -> Human Review / Expert Review / AI Draft
  -> Audit Ledger
  -> Feedback and Reputation Update
```

## Dispatch Actors

- Requester: user or organization submitting the task.
- AI Agent: draft, search, summarize, classify, generate tests.
- Human Reviewer: checks correctness and source support.
- Licensed Expert: reviews legal, medical, finance, public safety or employment issues.
- Operator: performs user-confirmed external action outside this offline core.
- Guardian: monitors policy, residuals, audit and recovery.
