try:
    import streamlit as st
except Exception:
    st = None

from pathlib import Path
import json
from .evaluator import dispatch

if st:
    st.title('DIKWP TaskRide OS')
    uploaded = st.file_uploader('Upload task marketplace case JSON', type=['json'])
    if uploaded:
        case=json.loads(uploaded.read().decode('utf-8'))
        result=dispatch(case, {})
        st.json(result.report)
        st.write('Task Cards')
        st.json(result.task_cards)
else:
    print('Install streamlit to run the optional UI.')
