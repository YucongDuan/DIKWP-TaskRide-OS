import json, csv
from pathlib import Path
from typing import List, Dict, Any
from .models import DispatchResult


def write_csv(path: Path, rows: List[Dict[str, Any]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys=list(rows[0].keys())
    with path.open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=keys)
        w.writeheader(); w.writerows(rows)


def write_outputs(result: DispatchResult, out_dir: str):
    out=Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    (out/'taskride_report.json').write_text(json.dumps(result.report, ensure_ascii=False, indent=2), encoding='utf-8')
    (out/'task_cards.json').write_text(json.dumps(result.task_cards, ensure_ascii=False, indent=2), encoding='utf-8')
    (out/'semantic_closure_ledger.json').write_text(json.dumps(result.semantic_closure_ledger, ensure_ascii=False, indent=2), encoding='utf-8')
    write_csv(out/'dispatch_board.csv', result.task_cards)
    write_csv(out/'provider_matches.csv', result.provider_matches)
    write_csv(out/'pricing_quotes.csv', result.pricing_quotes)
    write_csv(out/'action_tickets.csv', result.action_tickets)
    write_csv(out/'trust_and_safety_queue.csv', result.trust_safety_queue)
    (out/'marketplace_policy.md').write_text(marketplace_policy(), encoding='utf-8')
    (out/'pilot_sow_draft.md').write_text(pilot_sow(result.report), encoding='utf-8')
    (out/'recommendations.md').write_text(recommendations(result.report), encoding='utf-8')


def marketplace_policy() -> str:
    return """# DIKWP TaskRide Marketplace Policy

## Allowed

- AI draft generation for low-risk tasks.
- Human-reviewed outputs for sensitive or high-impact domains.
- Evidence-based task fulfillment with audit records.
- Provider matching based on capability, availability, reliability and risk fit.

## Not Allowed

- Live external action without explicit user confirmation.
- Credential collection, CAPTCHA bypass, payment execution or hidden login.
- Automatic medical, legal, financial, employment, education or public-safety decisions.
- Worker exploitation, hidden surveillance, fake reviews, opaque pricing or forced arbitration.

## DIKWP Rule

Every dispatched task must have D/I/K/W/P/R registration, evidence or residual ledger, action ticket, provider accountability and recovery path.
"""


def pilot_sow(report: Dict[str, Any]) -> str:
    return f"""# Paid Pilot Statement of Work Draft

## Project

DIKWP TaskRide OS sandbox pilot.

## Scope

- Configure task categories.
- Build provider registry.
- Run dispatch on synthetic and customer-approved sample tasks.
- Generate task cards, provider matches, pricing quotes and action tickets.
- Review trust-and-safety queue with humans.

## Success Metrics

- Task triage precision.
- Human review routing accuracy.
- Evidence and residual completeness.
- Average dispatch preparation time.
- User acceptance of draft outputs.
- No live external execution without approval.

## Current Demo Summary

```json
{report}
```

## Boundaries

No payment integration, credential use, live browser automation or production write actions in the open-source core.
"""


def recommendations(report: Dict[str, Any]) -> str:
    return f"""# Recommendations

1. Start with three categories: research summary, customer support drafting and code review.
2. Require human review for medical, legal, financial, employment and public-safety tasks.
3. Use DIKWP TrustPassport for provider registry and official task fulfillment badge.
4. Route all high-risk steps to Action Tickets instead of direct execution.
5. Keep pricing transparent: base complexity + risk multiplier + review surcharge + rush surcharge.

Demo case: `{report.get('case_id')}`.
"""
