from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional

@dataclass
class TaskRequest:
    task_id: str
    title: str
    requester_type: str
    description: str
    domain: str
    expected_outputs: List[str]
    evidence_refs: List[str] = field(default_factory=list)
    constraints: List[str] = field(default_factory=list)
    forbidden_actions: List[str] = field(default_factory=list)
    urgency_hours: int = 72
    budget_cny: float = 0.0
    data_sensitivity: str = "normal"
    external_action_required: bool = False
    high_impact_domain: bool = False
    requires_professional_license: bool = False
    required_capabilities: List[str] = field(default_factory=list)

@dataclass
class Provider:
    provider_id: str
    name: str
    provider_type: str  # ai_agent, human_expert, reviewer, operator
    domains: List[str]
    capabilities: List[str]
    reliability_score: float
    hourly_rate_cny: float
    max_risk_level: int
    availability_hours: int
    certifications: List[str] = field(default_factory=list)

@dataclass
class IntentContract:
    goal: str
    value: str
    constraints: List[str]
    time_window: str
    feedback_plan: str

@dataclass
class TaskCard:
    task_id: str
    title: str
    domain: str
    risk_level: int
    semantic_stability: str
    decision: str
    recommended_route: str
    residuals: List[str]
    kill_conditions: List[str]

@dataclass
class ProviderMatch:
    task_id: str
    provider_id: str
    provider_name: str
    match_score: float
    role: str
    rationale: str

@dataclass
class ActionTicket:
    ticket_id: str
    task_id: str
    action_type: str
    title: str
    decision: str
    required_confirmation: bool
    evidence_refs: List[str]
    rollback_plan: str
    assigned_route: str
    risk_notes: List[str]

@dataclass
class PricingQuote:
    task_id: str
    base_price_cny: float
    risk_multiplier: float
    review_surcharge_cny: float
    rush_surcharge_cny: float
    estimated_total_cny: float
    pricing_basis: str

@dataclass
class DispatchResult:
    report: Dict[str, Any]
    task_cards: List[Dict[str, Any]]
    provider_matches: List[Dict[str, Any]]
    action_tickets: List[Dict[str, Any]]
    pricing_quotes: List[Dict[str, Any]]
    trust_safety_queue: List[Dict[str, Any]]
    semantic_closure_ledger: Dict[str, Any]
