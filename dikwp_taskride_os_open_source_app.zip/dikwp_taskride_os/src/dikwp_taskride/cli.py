import argparse, json
from pathlib import Path
from .evaluator import dispatch
from .reports import write_outputs
from .static_audit import audit_path


def main():
    parser=argparse.ArgumentParser(prog='taskride')
    sub=parser.add_subparsers(dest='cmd', required=True)
    p=sub.add_parser('dispatch')
    p.add_argument('case_json')
    p.add_argument('--policy', default='configs/default_policy.json')
    p.add_argument('--out', default='outputs/demo')
    a=sub.add_parser('static-audit')
    a.add_argument('path')
    a.add_argument('--out', default='outputs/demo/static_boundary_audit_report.json')
    args=parser.parse_args()
    if args.cmd=='dispatch':
        case=json.loads(Path(args.case_json).read_text(encoding='utf-8'))
        policy={}
        pp=Path(args.policy)
        if pp.exists(): policy=json.loads(pp.read_text(encoding='utf-8'))
        result=dispatch(case, policy)
        write_outputs(result, args.out)
        print(json.dumps(result.report, ensure_ascii=False, indent=2))
    elif args.cmd=='static-audit':
        result=audit_path(args.path)
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__=='__main__':
    main()
