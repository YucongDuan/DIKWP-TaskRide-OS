import hashlib, json, math
from dataclasses import asdict
from typing import Dict, List, Any, Tuple
from .models import TaskRequest, Provider, TaskCard, ProviderMatch, ActionTicket, PricingQuote, DispatchResult

HIGH_RISK_DOMAINS = {"medical", "legal", "finance", "public_safety", "employment", "education_high_stakes", "critical_infrastructure"}
SENSITIVE_TERMS = ["password", "api key", "session cookie", "secret", "credential", "身份证", "银行卡", "密码", "验证码"]
BLOCKED_ACTION_TERMS = ["bypass", "captcha", "disable audit", "hide logs", "自动付款", "自动退款", "自动裁员", "静默登录", "绕过", "关闭审计"]

DOMAIN_CAPABILITY_MAP = {
    "research": ["literature_review", "evidence_mapping", "claim_cards"],
    "legal": ["legal_draft", "citation_check", "human_legal_review"],
    "medical": ["medical_research_summary", "guideline_mapping", "clinician_review"],
    "customer_support": ["draft_reply", "ticket_classification", "crm_payload"],
    "software": ["code_review", "test_generation", "security_review"],
    "marketing": ["brief_generation", "answergraph", "proof_check"],
    "finance": ["risk_analysis", "audit_ledger", "human_finance_review"],
    "operations": ["workflow_design", "action_ticket", "agent_trace"],
}


def normalize_task(raw: Dict[str, Any]) -> TaskRequest:
    return TaskRequest(
        task_id=str(raw.get("task_id", "task-unknown")),
        title=str(raw.get("title", "Untitled Task")),
        requester_type=str(raw.get("requester_type", "unknown")),
        description=str(raw.get("description", "")),
        domain=str(raw.get("domain", "general")),
        expected_outputs=list(raw.get("expected_outputs", [])),
        evidence_refs=list(raw.get("evidence_refs", [])),
        constraints=list(raw.get("constraints", [])),
        forbidden_actions=list(raw.get("forbidden_actions", [])),
        urgency_hours=int(raw.get("urgency_hours", 72)),
        budget_cny=float(raw.get("budget_cny", 0)),
        data_sensitivity=str(raw.get("data_sensitivity", "normal")),
        external_action_required=bool(raw.get("external_action_required", False)),
        high_impact_domain=bool(raw.get("high_impact_domain", False)),
        requires_professional_license=bool(raw.get("requires_professional_license", False)),
        required_capabilities=list(raw.get("required_capabilities", [])),
    )


def normalize_provider(raw: Dict[str, Any]) -> Provider:
    return Provider(
        provider_id=str(raw.get("provider_id", "provider-unknown")),
        name=str(raw.get("name", "Unnamed Provider")),
        provider_type=str(raw.get("provider_type", "ai_agent")),
        domains=list(raw.get("domains", [])),
        capabilities=list(raw.get("capabilities", [])),
        reliability_score=float(raw.get("reliability_score", 0.5)),
        hourly_rate_cny=float(raw.get("hourly_rate_cny", 50)),
        max_risk_level=int(raw.get("max_risk_level", 2)),
        availability_hours=int(raw.get("availability_hours", 24)),
        certifications=list(raw.get("certifications", [])),
    )


def detect_risks(task: TaskRequest) -> Tuple[int, List[str]]:
    text = " ".join([task.title, task.description, " ".join(task.constraints), " ".join(task.forbidden_actions)]).lower()
    risk = 1
    notes = []
    if task.domain in HIGH_RISK_DOMAINS or task.high_impact_domain:
        risk = max(risk, 4)
        notes.append("high_impact_domain")
    if task.requires_professional_license:
        risk = max(risk, 4)
        notes.append("professional_license_required")
    if task.external_action_required:
        risk = max(risk, 3)
        notes.append("external_action_required")
    if task.data_sensitivity in {"personal_sensitive", "medical", "financial", "minor", "trade_secret"}:
        risk = max(risk, 3)
        notes.append(f"sensitive_data:{task.data_sensitivity}")
    if any(term in text for term in SENSITIVE_TERMS):
        risk = max(risk, 5)
        notes.append("credential_or_sensitive_secret_signal")
    if any(term in text for term in BLOCKED_ACTION_TERMS):
        risk = max(risk, 6)
        notes.append("blocked_action_signal")
    if task.urgency_hours <= 4:
        risk = max(risk, 3)
        notes.append("rush_or_crisis_timing")
    if not task.evidence_refs:
        notes.append("evidence_refs_missing")
    if not task.expected_outputs:
        notes.append("expected_outputs_missing")
    return min(risk, 6), notes


def semantic_stability(task: TaskRequest, risk_notes: List[str]) -> Tuple[str, List[str]]:
    residuals = []
    if not task.evidence_refs:
        residuals.append("No evidence references supplied; output must be draft/provisional.")
    if not task.expected_outputs:
        residuals.append("Expected deliverables are not explicit; ask for output format or use standard report pack.")
    if task.budget_cny <= 0:
        residuals.append("Budget missing; pricing estimate is provisional.")
    if "blocked_action_signal" in risk_notes:
        return "S0 Blocked Closure", residuals
    if task.domain in HIGH_RISK_DOMAINS and not task.requires_professional_license:
        residuals.append("High-impact domain needs explicit licensed human review policy.")
        return "S2 Provisional Closure", residuals
    if residuals:
        return "S3 Supported Closure" if len(residuals) <= 2 else "S2 Provisional Closure", residuals
    return "S4 Stable Closure", residuals


def decision_for(task: TaskRequest, risk: int, stability: str) -> Tuple[str, str]:
    if risk >= 6 or stability.startswith("S0"):
        return "blocked_or_scope_rewrite", "trust_and_safety_rewrite"
    if risk >= 5:
        return "blocked_pending_official_review", "licensed_expert_and_safety_board"
    if risk >= 4:
        return "human_expert_required", "ai_draft_plus_licensed_human_review"
    if risk == 3:
        return "ai_with_human_review", "ai_agent_plus_human_reviewer"
    return "auto_ai_draft_allowed", "ai_agent_with_optional_review"


def capability_match_score(task: TaskRequest, provider: Provider, risk: int) -> float:
    domain_score = 1.0 if task.domain in provider.domains else (0.5 if "general" in provider.domains else 0.0)
    reqs = set(task.required_capabilities or DOMAIN_CAPABILITY_MAP.get(task.domain, []))
    caps = set(provider.capabilities)
    cap_score = len(reqs & caps) / max(1, len(reqs))
    risk_fit = 1.0 if provider.max_risk_level >= risk else max(0.0, 1 - 0.25*(risk-provider.max_risk_level))
    availability = 1.0 if provider.availability_hours <= max(task.urgency_hours, 1) else 0.65
    reliability = provider.reliability_score
    return round(0.28*domain_score + 0.32*cap_score + 0.25*reliability + 0.10*risk_fit + 0.05*availability, 4)


def route_matches(task: TaskRequest, providers: List[Provider], risk: int, decision: str) -> List[ProviderMatch]:
    scored=[]
    for p in providers:
        s=capability_match_score(task,p,risk)
        if s>0.25:
            role = "primary_ai_draft" if p.provider_type=="ai_agent" else ("human_review" if p.provider_type in {"human_expert","reviewer"} else "operator")
            if decision in {"human_expert_required", "blocked_pending_official_review"} and p.provider_type == "ai_agent":
                role = "draft_only_not_final"
            scored.append((s,p,role))
    scored.sort(reverse=True, key=lambda x:x[0])
    return [ProviderMatch(task.task_id,p.provider_id,p.name,s,role,f"domain/capability/reliability/risk fit score={s}") for s,p,role in scored[:4]]


def price_quote(task: TaskRequest, matches: List[ProviderMatch], providers: Dict[str, Provider], risk: int) -> PricingQuote:
    # coarse complexity estimate
    complexity = 1 + 0.25*len(task.expected_outputs) + 0.2*len(task.required_capabilities) + 0.25*risk
    min_hours = max(1.0, complexity)
    primary_rates = [providers[m.provider_id].hourly_rate_cny for m in matches if m.provider_id in providers]
    rate = min(primary_rates) if primary_rates else 80.0
    base = min_hours * rate
    risk_multiplier = 1.0 + 0.18*risk
    review_surcharge = 0.0
    if risk >= 3:
        review_surcharge += 300
    if risk >= 4:
        review_surcharge += 700
    rush = 300 if task.urgency_hours <= 8 else (120 if task.urgency_hours <= 24 else 0)
    total = base*risk_multiplier + review_surcharge + rush
    if task.budget_cny > 0 and total > task.budget_cny:
        basis = "Estimated total exceeds stated budget; scope reduction or subsidy needed."
    else:
        basis = "Prototype estimate based on complexity, provider rate, risk multiplier, review and rush surcharge."
    return PricingQuote(task.task_id, round(base,2), round(risk_multiplier,2), review_surcharge, rush, round(total,2), basis)


def make_ticket(task: TaskRequest, risk:int, decision:str, route:str, evidence_refs: List[str]) -> ActionTicket:
    h = hashlib.sha256((task.task_id+decision+route).encode()).hexdigest()[:10]
    required = decision not in {"auto_ai_draft_allowed"}
    if decision.startswith("blocked"):
        title = f"Rewrite or escalate task scope: {task.title}"
        action_type = "scope_rewrite_or_safety_review"
        rollback = "No external action allowed; retain only redacted planning artifacts."
    elif decision == "human_expert_required":
        title = f"Licensed or domain expert review required: {task.title}"
        action_type = "expert_review_ticket"
        rollback = "Downgrade output to non-decision draft if expert review unavailable."
    elif decision == "ai_with_human_review":
        title = f"AI draft with human review: {task.title}"
        action_type = "draft_review_ticket"
        rollback = "Discard draft and regenerate after clarifying residuals."
    else:
        title = f"AI draft allowed: {task.title}"
        action_type = "ai_draft_ticket"
        rollback = "Discard draft; no external action has occurred."
    return ActionTicket(
        ticket_id=f"ticket-{h}", task_id=task.task_id, action_type=action_type, title=title,
        decision=decision, required_confirmation=required, evidence_refs=evidence_refs,
        rollback_plan=rollback, assigned_route=route,
        risk_notes=[f"risk_level={risk}"]
    )


def dikwp_record(task: TaskRequest, risk:int, stability:str, residuals: List[str], risk_notes: List[str]) -> Dict[str, Any]:
    return {
        "task_id": task.task_id,
        "C": {
            "D": {
                "explicit_description": task.description,
                "domain": task.domain,
                "evidence_refs": task.evidence_refs,
                "expected_outputs": task.expected_outputs
            },
            "I": {
                "relations": ["requester-task", "task-provider", "task-evidence", "task-action-ticket"],
                "sensitivity": task.data_sensitivity,
                "external_action_required": task.external_action_required
            },
            "K": {
                "capability_requirements": task.required_capabilities or DOMAIN_CAPABILITY_MAP.get(task.domain, []),
                "domain_policy": "high-impact domains require human review" if task.domain in HIGH_RISK_DOMAINS else "standard task governance"
            },
            "W": {
                "risk_level": risk,
                "risk_notes": risk_notes,
                "forbidden_actions": task.forbidden_actions,
                "action_boundary": "no live external execution in offline core"
            },
            "P": {
                "goal": f"complete or prepare task: {task.title}",
                "value": "reduce friction while preserving evidence, consent and review boundaries",
                "constraints": task.constraints,
                "time_window": f"{task.urgency_hours} hours",
                "feedback_plan": "human review, audit ledger, provider score update, user acceptance"
            },
            "R": {
                "semantic_stability": stability,
                "residuals": residuals,
                "reliability": "Supported" if stability.startswith("S4") else ("Provisional" if stability.startswith("S2") else "Borrowed/Supported")
            }
        }
    }


def dispatch(case: Dict[str, Any], policy: Dict[str, Any] = None) -> DispatchResult:
    tasks=[normalize_task(x) for x in case.get("tasks", [])]
    providers=[normalize_provider(x) for x in case.get("providers", [])]
    provider_map={p.provider_id:p for p in providers}

    cards=[]; matches_all=[]; quotes=[]; tickets=[]; trust=[]; ledgers=[]
    for task in tasks:
        risk, risk_notes = detect_risks(task)
        stability, residuals = semantic_stability(task, risk_notes)
        decision, route = decision_for(task, risk, stability)
        card=TaskCard(task.task_id, task.title, task.domain, risk, stability, decision, route, residuals,
                      kill_conditions=["New evidence shows task is illegal or harmful", "Requester asks to bypass consent, payment, credentials or audit", "High-impact domain lacks licensed review" if risk>=4 else "Provider reliability falls below threshold"])
        cards.append(asdict(card))
        matches=route_matches(task, providers, risk, decision)
        matches_all.extend([asdict(m) for m in matches])
        quote=price_quote(task, matches, provider_map, risk)
        quotes.append(asdict(quote))
        ticket=make_ticket(task, risk, decision, route, task.evidence_refs)
        tickets.append(asdict(ticket))
        ledgers.append(dikwp_record(task, risk, stability, residuals, risk_notes))
        if decision.startswith("blocked") or risk>=4 or risk_notes:
            trust.append({
                "task_id": task.task_id, "title": task.title, "risk_level": risk,
                "decision": decision, "risk_notes": risk_notes, "required_review": True if risk>=3 else bool(risk_notes),
                "residuals": residuals
            })

    summary={}
    for c in cards: summary[c["decision"]]=summary.get(c["decision"],0)+1
    report={
        "system":"DIKWP TaskRide OS",
        "version":"0.1.0",
        "case_id":case.get("case_id","unknown"),
        "marketplace_route":"pilot_marketplace_dispatch",
        "task_count":len(tasks),
        "provider_count":len(providers),
        "decision_summary":summary,
        "mean_risk_level": round(sum(c["risk_level"] for c in cards)/max(1,len(cards)),2),
        "semantic_stability_distribution": {s:sum(1 for c in cards if c["semantic_stability"]==s) for s in sorted(set(c["semantic_stability"] for c in cards))},
        "action_boundary":"Offline dispatch, planning, pricing and audit only; no payment, credential use, browser automation or external execution.",
        "recommended_next_step":"Run 2-week sandbox pilot with curated task categories, provider registry and human review SLAs."
    }
    closure={"case_id":case.get("case_id","unknown"),"ledger_count":len(ledgers),"records":ledgers}
    return DispatchResult(report, cards, matches_all, tickets, quotes, trust, closure)
