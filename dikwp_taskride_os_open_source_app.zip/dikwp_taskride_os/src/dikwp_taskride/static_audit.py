from pathlib import Path
import ast

FORBIDDEN_IMPORTS = {'requests','urllib','httpx','aiohttp','socket','subprocess','os'}
FORBIDDEN_CALLS = {'eval','exec','compile','__import__'}
FORBIDDEN_TERMS = []  # Names are checked only when imported or called, not when mentioned in policy text.

def audit_file(path: Path):
    findings=[]
    text=path.read_text(encoding='utf-8')
    try:
        tree=ast.parse(text)
    except SyntaxError as e:
        findings.append({'file':str(path),'type':'syntax_error','value':str(e)})
        return findings
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                base=alias.name.split('.')[0]
                if base in FORBIDDEN_IMPORTS:
                    findings.append({'file':str(path),'type':'forbidden_import','value':alias.name})
        elif isinstance(node, ast.ImportFrom):
            base=(node.module or '').split('.')[0]
            if base in FORBIDDEN_IMPORTS:
                findings.append({'file':str(path),'type':'forbidden_import','value':node.module})
        elif isinstance(node, ast.Call):
            name=''
            if isinstance(node.func, ast.Name): name=node.func.id
            elif isinstance(node.func, ast.Attribute): name=node.func.attr
            if name in FORBIDDEN_CALLS:
                findings.append({'file':str(path),'type':'forbidden_call','value':name})
    return findings

def audit_path(path: str):
    p=Path(path)
    files=list(p.rglob('*.py')) if p.is_dir() else [p]
    findings=[]
    for f in files:
        findings.extend(audit_file(f))
    return {
        'pass': len(findings)==0,
        'finding_count': len(findings),
        'findings': findings,
        'policy': 'No network imports, browser automation, subprocess, dynamic execution, credential capture, payment execution, hidden telemetry, or host mutation helpers in the offline core.'
    }
