# Code of Conduct

Be respectful. Do not use this project to exploit workers, evade laws, bypass platform restrictions, or automate high-risk real-world actions.
