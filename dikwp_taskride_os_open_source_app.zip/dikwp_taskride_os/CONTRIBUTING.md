# Contributing

Contributions should preserve the DIKWP ledger, SemanticClosure output, trust-and-safety boundary, and human review gates.
