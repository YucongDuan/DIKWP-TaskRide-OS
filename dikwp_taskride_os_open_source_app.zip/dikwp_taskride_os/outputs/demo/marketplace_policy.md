# DIKWP TaskRide Marketplace Policy

## Allowed

- AI draft generation for low-risk tasks.
- Human-reviewed outputs for sensitive or high-impact domains.
- Evidence-based task fulfillment with audit records.
- Provider matching based on capability, availability, reliability and risk fit.

## Not Allowed

- Live external action without explicit user confirmation.
- Credential collection, CAPTCHA bypass, payment execution or hidden login.
- Automatic medical, legal, financial, employment, education or public-safety decisions.
- Worker exploitation, hidden surveillance, fake reviews, opaque pricing or forced arbitration.

## DIKWP Rule

Every dispatched task must have D/I/K/W/P/R registration, evidence or residual ledger, action ticket, provider accountability and recovery path.
