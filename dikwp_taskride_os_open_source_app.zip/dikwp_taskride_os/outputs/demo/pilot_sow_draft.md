# Paid Pilot Statement of Work Draft

## Project

DIKWP TaskRide OS sandbox pilot.

## Scope

- Configure task categories.
- Build provider registry.
- Run dispatch on synthetic and customer-approved sample tasks.
- Generate task cards, provider matches, pricing quotes and action tickets.
- Review trust-and-safety queue with humans.

## Success Metrics

- Task triage precision.
- Human review routing accuracy.
- Evidence and residual completeness.
- Average dispatch preparation time.
- User acceptance of draft outputs.
- No live external execution without approval.

## Current Demo Summary

```json
{'system': 'DIKWP TaskRide OS', 'version': '0.1.0', 'case_id': 'taskride-demo-001', 'marketplace_route': 'pilot_marketplace_dispatch', 'task_count': 4, 'provider_count': 5, 'decision_summary': {'auto_ai_draft_allowed': 2, 'ai_with_human_review': 1, 'blocked_or_scope_rewrite': 1}, 'mean_risk_level': 2.75, 'semantic_stability_distribution': {'S0 Blocked Closure': 1, 'S4 Stable Closure': 3}, 'action_boundary': 'Offline dispatch, planning, pricing and audit only; no payment, credential use, browser automation or external execution.', 'recommended_next_step': 'Run 2-week sandbox pilot with curated task categories, provider registry and human review SLAs.'}
```

## Boundaries

No payment integration, credential use, live browser automation or production write actions in the open-source core.
