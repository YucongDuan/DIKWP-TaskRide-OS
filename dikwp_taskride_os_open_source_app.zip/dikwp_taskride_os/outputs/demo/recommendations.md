# Recommendations

1. Start with three categories: research summary, customer support drafting and code review.
2. Require human review for medical, legal, financial, employment and public-safety tasks.
3. Use DIKWP TrustPassport for provider registry and official task fulfillment badge.
4. Route all high-risk steps to Action Tickets instead of direct execution.
5. Keep pricing transparent: base complexity + risk multiplier + review surcharge + rush surcharge.

Demo case: `taskride-demo-001`.
