import json
from pathlib import Path
from dikwp_taskride.evaluator import dispatch
from dikwp_taskride.static_audit import audit_path


def test_dispatch_demo():
    case=json.loads(Path('examples/sample_task_market_case.json').read_text(encoding='utf-8'))
    result=dispatch(case,{})
    assert result.report['task_count']==4
    assert 'blocked_or_scope_rewrite' in result.report['decision_summary'] or 'blocked_pending_official_review' in result.report['decision_summary']
    assert len(result.action_tickets)==4


def test_coffee_like_semantic_stability_for_safe_task():
    case=json.loads(Path('examples/sample_task_market_case.json').read_text(encoding='utf-8'))
    result=dispatch(case,{})
    research=[c for c in result.task_cards if c['task_id']=='t-research-001'][0]
    assert research['semantic_stability'] in {'S4 Stable Closure','S3 Supported Closure'}


def test_static_audit_passes():
    result=audit_path('src')
    assert result['pass'] is True
